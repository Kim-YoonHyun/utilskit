0.2.0 
- 정식 최초 배포버전
- 각 함수의 사용성 강화 및 비활성 함수 지정
0.1.2
- repeatutils 의 get_repeat_section 에서 하나의 값이 여러 구간에서 반복될때 마지막 구간만 나오는 부분 수정
- repeatutils 의 get_repeat_section 및 get_stan_repeat_section 에서 추출되는 구간의 마지막 값이 +1 이 되는 부분 수정
0.1.1
repeatutils.py 추가
utils.py 에서 repeat 관련 함수 제거